#include "uavsimulator.h"
#include "mavlinkmessageparser.h"
#include <QNetworkDatagram>
#include <cmath>

UavSimulator::UavSimulator(QObject *parent)
    : QObject(parent)
{
    m_udpSocket = new QUdpSocket(this);
    // Привязываем порт эмулятора для приёма COMMAND_LONG от НСУ
    m_udpSocket->bind(QHostAddress::AnyIPv4, 14550);
    connect(m_udpSocket, &QUdpSocket::readyRead,
            this, &UavSimulator::onReadyRead);

    m_telemetryTimer = new QTimer(this);
    m_telemetryTimer->setInterval(100); // 10 Гц
    connect(m_telemetryTimer, &QTimer::timeout,
            this, &UavSimulator::sendTelemetry);

    m_heartbeatTimer = new QTimer(this);
    m_heartbeatTimer->setInterval(1000); // 1 Гц
    connect(m_heartbeatTimer, &QTimer::timeout,
            this, &UavSimulator::sendHeartbeat);
}

void UavSimulator::start(const QString &targetAddress, quint16 targetPort)
{
    m_targetAddress = targetAddress;
    m_targetPort = targetPort;
    m_telemetryTimer->start();
    m_heartbeatTimer->start();

    emit simulatorStateChanged(true);
    emit simulatorLog(QString("Эмулятор БПЛА запущен -> %1:%2 (10 Гц)").arg(m_targetAddress).arg(m_targetPort));
    sendHeartbeat();
}

void UavSimulator::stop()
{
    m_telemetryTimer->stop();
    m_heartbeatTimer->stop();
    emit simulatorStateChanged(false);
    emit simulatorLog("Эмулятор БПЛА остановлен (имитация потери связи)");
}

bool UavSimulator::isRunning() const
{
    return m_telemetryTimer->isActive();
}

void UavSimulator::corruptNextPacket()
{
    m_corruptNextPacket = true;
    emit simulatorLog("Запланировано повреждение следующего пакета");
}

void UavSimulator::dropNextPackets(int count)
{
    m_dropRemaining = count;
    emit simulatorLog(QString("Запланирован пропуск следующих %1 пакетов").arg(count));
}

void UavSimulator::sendHeartbeat()
{
    const quint8 seq = m_sequence++;
    if (m_dropRemaining > 0) {
        m_dropRemaining--;
        return;
    }

    QByteArray datagram = MavlinkMessageParser::buildHeartbeatPacket(
        seq, m_systemId, m_componentId, m_flightMode);

    m_udpSocket->writeDatagram(datagram, QHostAddress(m_targetAddress), m_targetPort);
}

void UavSimulator::sendTelemetry()
{
    // Плавное изменение высоты к целевой
    if (m_flightMode == 4) { // GUIDED (Взлёт)
        if (m_altitude < m_targetAltitude) {
            m_altitude = std::min(m_targetAltitude, m_altitude + 0.8);
        } else if (m_altitude > m_targetAltitude) {
            m_altitude = std::max(m_targetAltitude, m_altitude - 0.8);
        }
    } else if (m_flightMode == 6) { // LAND (Посадка)
        if (m_altitude > 0.0) {
            m_altitude = std::max(0.0, m_altitude - 0.8);
        } else {
            m_flightMode = 0; // MANUAL на земле
        }
    } else if (m_flightMode == 0 && m_altitude == 0.0) {
        // Если режим MANUAL и не было команды, демонстрационный набор высоты до 50 м
        // оставляем 0 до команды или легкий дрейф координат
    }

    // Небольшое движение по кругу при наборе высоты
    if (m_altitude > 0.5) {
        static double angle = 0.0;
        angle += 0.02;
        m_latitude = 55.7522200 + 0.0005 * std::cos(angle);
        m_longitude = 37.6155600 + 0.0008 * std::sin(angle);
    }

    const quint8 seq = m_sequence++;
    if (m_dropRemaining > 0) {
        m_dropRemaining--;
        return;
    }

    QByteArray datagram = MavlinkMessageParser::buildGlobalPositionPacket(
        seq, m_systemId, m_componentId, m_latitude, m_longitude, m_altitude, m_flightMode);

    if (m_corruptNextPacket && datagram.size() > 4) {
        datagram[3] = static_cast<char>(static_cast<quint8>(datagram[3]) ^ 0xFF);
        m_corruptNextPacket = false;
    }

    m_udpSocket->writeDatagram(datagram, QHostAddress(m_targetAddress), m_targetPort);
}

void UavSimulator::onReadyRead()
{
    while (m_udpSocket->hasPendingDatagrams()) {
        QNetworkDatagram dgram = m_udpSocket->receiveDatagram();
        if (!dgram.isValid()) continue;

        ParsedMavlinkPacket packet = MavlinkMessageParser::parsePacket(dgram.data());
        if (!packet.valid || packet.msgid != MAVLINK_MSG_ID_COMMAND_LONG) {
            continue;
        }

        quint8 ackResult = MAV_RESULT_ACCEPTED;

        if (packet.command == MAV_CMD_NAV_TAKEOFF) {
            m_targetAltitude = static_cast<double>(packet.param7);
            m_flightMode = 4; // GUIDED
            emit simulatorLog(QString("Принята команда TAKEOFF на высоту %1 м").arg(m_targetAltitude, 0, 'f', 0));
        } else if (packet.command == MAV_CMD_NAV_LAND) {
            m_targetAltitude = 0.0;
            m_flightMode = 6; // LAND
            emit simulatorLog("Принята команда LAND (снижение)");
        } else if (packet.command == MAV_CMD_DO_FLIGHTTERMINATION) {
            m_targetAltitude = m_altitude;
            m_flightMode = 3; // POS_HOLD
            emit simulatorLog("Принята команда СТОП (удержание текущей высоты)");
        } else {
            ackResult = MAV_RESULT_UNSUPPORTED;
        }

        const QByteArray ackPacket = MavlinkMessageParser::buildCommandAckPacket(
            m_sequence++, m_systemId, m_componentId, packet.command, ackResult);

        m_udpSocket->writeDatagram(ackPacket, dgram.senderAddress(), dgram.senderPort());
    }
}
