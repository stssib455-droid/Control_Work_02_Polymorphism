#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "telemetrymodel.h"
#include "mavlinkmanager.h"
#include "uavsimulator.h"

#include <QMessageBox>
#include <QTime>
#include <QHeaderView>
#include <QTableWidgetItem>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("НСУ БПЛА — MAVLink Ground Station (Вариант 3)");

    m_telemetryModel = new TelemetryModel(this);
    m_mavlinkManager = new MavlinkManager(m_telemetryModel, this);
    m_uavSimulator = new UavSimulator(this);

    // Настройка spinTakeoffAltitude по заданию 3
    ui->spinTakeoffAltitude->setMinimum(10.0);
    ui->spinTakeoffAltitude->setMaximum(500.0);
    ui->spinTakeoffAltitude->setSingleStep(10.0);
    ui->spinTakeoffAltitude->setValue(50.0);
    ui->spinTakeoffAltitude->setSuffix(" м");

    setupChart();
    setupTelemetryTable();

    // Безопасный режим при старте: связи нет -> кнопки команд заблокированы (Вариант 3)
    setCommandButtonsEnabled(false);
    ui->btnStopLink->setEnabled(false);
    ui->btnDisconnectUav->setEnabled(false);

    // Соединения указательным синтаксисом connect
    connect(m_mavlinkManager, &MavlinkManager::telemetryReceived,
            m_telemetryModel, &TelemetryModel::updateTelemetry);
    connect(m_telemetryModel, &TelemetryModel::telemetryChanged,
            this, &MainWindow::onTelemetryChanged);

    connect(m_mavlinkManager, &MavlinkManager::linkStateChanged,
            m_telemetryModel, &TelemetryModel::updateLink);
    connect(m_telemetryModel, &TelemetryModel::linkStateChanged,
            this, &MainWindow::onLinkStateChanged);

    connect(m_mavlinkManager, &MavlinkManager::packetReceived,
            this, &MainWindow::onPacketReceived);
    connect(m_mavlinkManager, &MavlinkManager::commandResult,
            this, &MainWindow::onCommandResult);
    connect(m_mavlinkManager, &MavlinkManager::errorOccurred,
            this, &MainWindow::onMavlinkError);
    connect(m_mavlinkManager, &MavlinkManager::networkEventLogged,
            this, &MainWindow::appendNetworkEvent);

    connect(m_uavSimulator, &UavSimulator::simulatorLog,
            this, &MainWindow::appendNetworkEvent);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupChart()
{
    m_altitudeSeries = new QLineSeries();
    m_altitudeSeries->setName("Высота, м");

    m_chart = new QChart();
    m_chart->addSeries(m_altitudeSeries);
    m_chart->setTitle("График высоты БПЛА в реальном времени");
    m_chart->legend()->setVisible(true);

    m_axisX = new QValueAxis();
    m_axisX->setTitleText("Время, с");
    m_axisX->setRange(0, 30);

    m_axisY = new QValueAxis();
    m_axisY->setTitleText("Высота, м");
    m_axisY->setRange(0, 150);

    m_chart->addAxis(m_axisX, Qt::AlignBottom);
    m_chart->addAxis(m_axisY, Qt::AlignLeft);
    m_altitudeSeries->attachAxis(m_axisX);
    m_altitudeSeries->attachAxis(m_axisY);

    ui->chartView->setChart(m_chart);
    ui->chartView->setRenderHint(QPainter::Antialiasing);
}

void MainWindow::setupTelemetryTable()
{
    // Вариант 3 задания 2: таблица телеметрии
    ui->tableTelemetry->setColumnCount(7);
    ui->tableTelemetry->setHorizontalHeaderLabels({
        "Время", "System ID", "Component ID", "Широта", "Долгота", "Высота", "Режим"
    });
    ui->tableTelemetry->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableTelemetry->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

void MainWindow::setCommandButtonsEnabled(bool enabled)
{
    // Вариант 3 задания 4: блокировка критичных кнопок при потере связи
    ui->btnTakeoff->setEnabled(enabled);
    ui->btnLand->setEnabled(enabled);
    ui->btnStop->setEnabled(enabled);
}

void MainWindow::on_btnStartLink_clicked()
{
    const quint16 port = static_cast<quint16>(ui->spinListenPort->value());
    if (m_mavlinkManager->start(port)) {
        ui->btnStartLink->setEnabled(false);
        ui->btnStopLink->setEnabled(true);
        ui->spinListenPort->setEnabled(false);
    }
}

void MainWindow::on_btnStopLink_clicked()
{
    m_mavlinkManager->stop();
    ui->btnStartLink->setEnabled(true);
    ui->btnStopLink->setEnabled(false);
    ui->spinListenPort->setEnabled(true);
    setCommandButtonsEnabled(false);
}

void MainWindow::on_btnTakeoff_clicked()
{
    if (!m_telemetryModel->isLinkConnected()) {
        QMessageBox::warning(
            this,
            "Команда недоступна",
            "Невозможно отправить команду взлёта: нет связи с БПЛА.");
        return;
    }

    // Вариант 3 задания 3: подтверждение оператором перед отправкой команды взлёта
    const QMessageBox::StandardButton answer = QMessageBox::question(
        this,
        "Подтверждение команды",
        "Отправить команду взлёта на высоту "
            + QString::number(ui->spinTakeoffAltitude->value(), 'f', 0)
            + " м?",
        QMessageBox::Yes | QMessageBox::No,
        QMessageBox::No);

    if (answer != QMessageBox::Yes) {
        return;
    }

    ui->labelCommandStatus->setText("Статус: Ожидание COMMAND_ACK...");
    ui->labelCommandStatus->setStyleSheet("color: #d97706; font-weight: bold;");
    m_mavlinkManager->sendTakeoff(ui->spinTakeoffAltitude->value());
}

void MainWindow::on_btnLand_clicked()
{
    if (!m_telemetryModel->isLinkConnected()) {
        QMessageBox::warning(this, "Команда недоступна", "Нет связи с БПЛА.");
        return;
    }
    ui->labelCommandStatus->setText("Статус: Ожидание COMMAND_ACK...");
    ui->labelCommandStatus->setStyleSheet("color: #d97706; font-weight: bold;");
    m_mavlinkManager->sendLand();
}

void MainWindow::on_btnStop_clicked()
{
    if (!m_telemetryModel->isLinkConnected()) {
        QMessageBox::warning(this, "Команда недоступна", "Нет связи с БПЛА.");
        return;
    }
    ui->labelCommandStatus->setText("Статус: Ожидание COMMAND_ACK...");
    ui->labelCommandStatus->setStyleSheet("color: #d97706; font-weight: bold;");
    m_mavlinkManager->sendStop();
}

void MainWindow::on_btnStartUav_clicked()
{
    const quint16 targetPort = static_cast<quint16>(ui->spinListenPort->value());
    m_uavSimulator->start("127.0.0.1", targetPort);
    ui->btnStartUav->setEnabled(false);
    ui->btnDisconnectUav->setEnabled(true);
}

void MainWindow::on_btnDisconnectUav_clicked()
{
    m_uavSimulator->stop();
    ui->btnStartUav->setEnabled(true);
    ui->btnDisconnectUav->setEnabled(false);
}

void MainWindow::on_btnCorruptPacket_clicked()
{
    m_uavSimulator->corruptNextPacket();
}

void MainWindow::on_btnDropPackets_clicked()
{
    m_uavSimulator->dropNextPackets(2);
}

void MainWindow::onTelemetryChanged(double latitude,
                                    double longitude,
                                    double altitude,
                                    const QString &flightMode,
                                    quint8 systemId,
                                    quint8 componentId)
{
    ui->labelLatitude->setText(QString::number(latitude, 'f', 7));
    ui->labelLongitude->setText(QString::number(longitude, 'f', 7));
    ui->labelAltitude->setText(QString::number(altitude, 'f', 1) + " м");
    ui->labelFlightMode->setText(flightMode);

    // Обновление графика (не более 300 точек)
    m_altitudeSeries->append(m_timeSeconds, altitude);
    m_timeSeconds += 0.1;
    if (m_altitudeSeries->count() > 300) {
        m_altitudeSeries->remove(0);
    }
    if (m_timeSeconds > 30.0) {
        m_axisX->setRange(m_timeSeconds - 30.0, m_timeSeconds);
    }
    if (altitude + 20.0 > m_axisY->max()) {
        m_axisY->setMax(altitude + 30.0);
    }

    // Вариант 3 задания 2: добавление строки в таблицу не чаще 1 раза в секунду, лимит 200 строк
    const QDateTime now = QDateTime::currentDateTime();
    if (!m_lastTableInsertTime.isValid() || m_lastTableInsertTime.msecsTo(now) >= 1000) {
        m_lastTableInsertTime = now;

        const int row = ui->tableTelemetry->rowCount();
        ui->tableTelemetry->insertRow(row);
        ui->tableTelemetry->setItem(row, 0, new QTableWidgetItem(now.toString("hh:mm:ss")));
        ui->tableTelemetry->setItem(row, 1, new QTableWidgetItem(QString::number(systemId)));
        ui->tableTelemetry->setItem(row, 2, new QTableWidgetItem(QString::number(componentId)));
        ui->tableTelemetry->setItem(row, 3, new QTableWidgetItem(QString::number(latitude, 'f', 7)));
        ui->tableTelemetry->setItem(row, 4, new QTableWidgetItem(QString::number(longitude, 'f', 7)));
        ui->tableTelemetry->setItem(row, 5, new QTableWidgetItem(QString::number(altitude, 'f', 1)));
        ui->tableTelemetry->setItem(row, 6, new QTableWidgetItem(flightMode));

        if (ui->tableTelemetry->rowCount() > 200) {
            ui->tableTelemetry->removeRow(0);
        }
        ui->tableTelemetry->scrollToBottom();
    }
}

void MainWindow::onLinkStateChanged(bool connected,
                                    const QString &address,
                                    quint16 port)
{
    if (connected) {
        // Вариант 3 задания 4: разблокировка кнопок и уведомление «Связь восстановлена»
        setCommandButtonsEnabled(true);
        if (m_wasEverConnected) {
            ui->labelLinkStatus->setText("Связь восстановлена");
            appendNetworkEvent("Связь восстановлена");
        } else {
            ui->labelLinkStatus->setText("Связь установлена");
            m_wasEverConnected = true;
        }
        ui->labelLinkStatus->setStyleSheet("color: green; font-weight: bold;");
        ui->labelSender->setText(address + ":" + QString::number(port));
    } else {
        // Вариант 3 задания 4: безопасный режим НСУ при потере связи
        setCommandButtonsEnabled(false);
        ui->labelLinkStatus->setText(m_wasEverConnected ? "Связь потеряна" : "Связь отсутствует");
        ui->labelLinkStatus->setStyleSheet("color: red; font-weight: bold;");
        ui->labelSender->setText(address.isEmpty() ? "—" : (address + ":" + QString::number(port)));
    }
}

void MainWindow::onPacketReceived(quint64 received, quint64 lost, quint64 corrupted)
{
    ui->labelPackets->setText(
        QString("Принято: %1 | Потеряно: %2 | Ошибок CRC: %3")
            .arg(received)
            .arg(lost)
            .arg(corrupted));
}

void MainWindow::onCommandResult(int command,
                                 bool accepted,
                                 const QString &message)
{
    if (accepted) {
        ui->labelCommandStatus->setText("Статус: " + message);
        ui->labelCommandStatus->setStyleSheet("color: green; font-weight: bold;");
    } else {
        ui->labelCommandStatus->setText("Статус: " + message);
        ui->labelCommandStatus->setStyleSheet("color: red; font-weight: bold;");
    }

    const QString record = QString("[%1] COMMAND %2: %3")
                               .arg(QTime::currentTime().toString("hh:mm:ss"))
                               .arg(command)
                               .arg(message);
    ui->listCommandLog->insertItem(0, record);
}

void MainWindow::onMavlinkError(const QString &message)
{
    ui->labelLinkStatus->setText("Ошибка: " + message);
    ui->labelLinkStatus->setStyleSheet("color: red; font-weight: bold;");
}

void MainWindow::appendNetworkEvent(const QString &eventMessage)
{
    const QString entry = QString("[%1] %2")
                              .arg(QTime::currentTime().toString("hh:mm:ss"))
                              .arg(eventMessage);
    ui->listNetworkLog->insertItem(0, entry);
    if (ui->listNetworkLog->count() > 200) {
        delete ui->listNetworkLog->takeItem(ui->listNetworkLog->count() - 1);
    }
}
