#include "mavlinkmessageparser.h"
#include <QDataStream>
#include <QIODevice>
#include <QDateTime>
#include <cstring>

// Реализация CRC-16/MCRF4XX по стандарту MAVLink 2
quint16 MavlinkMessageParser::calculateCrc16(const QByteArray &dataWithoutMagicAndCrc, quint8 crcExtra)
{
    quint16 crc = 0xFFFF;
    auto accumulate = [&crc](quint8 byte) {
        quint8 tmp = byte ^ static_cast<quint8>(crc & 0xFF);
        tmp ^= (tmp << 4);
        crc = (crc >> 8) ^ (static_cast<quint16>(tmp) << 8)
              ^ (static_cast<quint16>(tmp) << 3)
              ^ (static_cast<quint16>(tmp) >> 4);
    };

    for (char c : dataWithoutMagicAndCrc) {
        accumulate(static_cast<quint8>(c));
    }
    accumulate(crcExtra);
    return crc;
}

quint8 MavlinkMessageParser::getCrcExtra(quint32 msgid)
{
    switch (msgid) {
    case MAVLINK_MSG_ID_HEARTBEAT: return 50;
    case MAVLINK_MSG_ID_GLOBAL_POSITION_INT: return 104;
    case MAVLINK_MSG_ID_COMMAND_LONG: return 152;
    case MAVLINK_MSG_ID_COMMAND_ACK: return 143;
    default: return 0;
    }
}

QString MavlinkMessageParser::flightModeToString(quint16 mode)
{
    switch (mode) {
    case 0: return "MANUAL";
    case 1: return "STABILIZED";
    case 2: return "ALT_HOLD";
    case 3: return "POS_HOLD";
    case 4: return "GUIDED";
    case 5: return "AUTO";
    case 6: return "LAND";
    default: return "UNKNOWN";
    }
}

bool MavlinkMessageParser::isValid(const QByteArray &data, QString *errorReason)
{
    // Минимальная длина MAVLink 2: 10 байт заголовка + 2 байта CRC = 12 байт
    if (data.size() < 12) {
        if (errorReason) *errorReason = "Слишком короткий MAVLink-пакет (< 12 байт)";
        return false;
    }

    const quint8 magic = static_cast<quint8>(data.at(0));
    if (magic != 0xFD) {
        if (errorReason) *errorReason = QString("Неверный стартовый байт: 0x%1 (ожидался 0xFD)")
                                            .arg(magic, 2, 16, QLatin1Char('0')).toUpper();
        return false;
    }

    const quint8 payloadLen = static_cast<quint8>(data.at(1));
    const int expectedSize = 10 + payloadLen + 2;
    if (data.size() != expectedSize) {
        if (errorReason) *errorReason = QString("Несоответствие длины пакета: получено %1 байт, ожидалось %2")
                                            .arg(data.size()).arg(expectedSize);
        return false;
    }

    const quint32 msgid = static_cast<quint8>(data.at(7))
                        | (static_cast<quint32>(static_cast<quint8>(data.at(8))) << 8)
                        | (static_cast<quint32>(static_cast<quint8>(data.at(9))) << 16);

    const quint16 receivedCrc = static_cast<quint8>(data.at(expectedSize - 2))
                              | (static_cast<quint16>(static_cast<quint8>(data.at(expectedSize - 1))) << 8);

    const QByteArray crcRegion = data.mid(1, 9 + payloadLen);
    const quint16 computedCrc = calculateCrc16(crcRegion, getCrcExtra(msgid));

    if (receivedCrc != computedCrc) {
        if (errorReason) *errorReason = QString("Ошибка контрольной суммы CRC-16 (получено 0x%1, расчёт 0x%2)")
                                            .arg(receivedCrc, 4, 16, QLatin1Char('0')).toUpper()
                                            .arg(computedCrc, 4, 16, QLatin1Char('0')).toUpper();
        return false;
    }

    return true;
}

ParsedMavlinkPacket MavlinkMessageParser::parsePacket(const QByteArray &data)
{
    ParsedMavlinkPacket result;
    if (!isValid(data, &result.errorReason)) {
        result.valid = false;
        return result;
    }

    result.valid = true;
    const quint8 payloadLen = static_cast<quint8>(data.at(1));
    result.seq = static_cast<quint8>(data.at(4));
    result.sysid = static_cast<quint8>(data.at(5));
    result.compid = static_cast<quint8>(data.at(6));
    result.msgid = static_cast<quint8>(data.at(7))
                 | (static_cast<quint32>(static_cast<quint8>(data.at(8))) << 8)
                 | (static_cast<quint32>(static_cast<quint8>(data.at(9))) << 16);

    const QByteArray payload = data.mid(10, payloadLen);
    QDataStream stream(payload);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream.setFloatingPointPrecision(QDataStream::SinglePrecision);

    if (result.msgid == MAVLINK_MSG_ID_HEARTBEAT && payloadLen >= 9) {
        quint32 customMode = 0;
        quint8 type = 0, autopilot = 0, baseMode = 0, systemStatus = 0, mavlinkVersion = 0;
        stream >> customMode >> type >> autopilot >> baseMode >> systemStatus >> mavlinkVersion;
        result.flightModeCode = static_cast<quint16>(customMode);
        result.flightModeName = flightModeToString(result.flightModeCode);
    } else if (result.msgid == MAVLINK_MSG_ID_GLOBAL_POSITION_INT && payloadLen >= 20) {
        quint32 timeBootMs = 0;
        qint32 latE7 = 0, lonE7 = 0, altMm = 0;
        quint16 flightMode = 0;
        stream >> timeBootMs >> latE7 >> lonE7 >> altMm >> flightMode;
        result.latitude = latE7 / 1e7;
        result.longitude = lonE7 / 1e7;
        result.altitude = altMm / 1000.0;
        result.flightModeCode = flightMode;
        result.flightModeName = flightModeToString(flightMode);
    } else if (result.msgid == MAVLINK_MSG_ID_COMMAND_LONG && payloadLen >= 11) {
        float param7 = 0.0f;
        quint16 command = 0;
        quint8 targetSys = 0, targetComp = 0, confirmation = 0;
        stream >> param7 >> command >> targetSys >> targetComp >> confirmation;
        result.param7 = param7;
        result.command = command;
    } else if (result.msgid == MAVLINK_MSG_ID_COMMAND_ACK && payloadLen >= 3) {
        quint16 command = 0;
        quint8 ackRes = 0;
        stream >> command >> ackRes;
        result.ackCommand = command;
        result.ackResult = ackRes;
    }

    return result;
}

static QByteArray wrapMavlink2Packet(quint8 seq, quint8 sysid, quint8 compid, quint32 msgid, const QByteArray &payload)
{
    QByteArray packet;
    packet.reserve(12 + payload.size());
    packet.append(static_cast<char>(0xFD)); // magic MAVLink 2
    packet.append(static_cast<char>(payload.size())); // len
    packet.append(static_cast<char>(0x00)); // incompat_flags
    packet.append(static_cast<char>(0x00)); // compat_flags
    packet.append(static_cast<char>(seq));
    packet.append(static_cast<char>(sysid));
    packet.append(static_cast<char>(compid));
    packet.append(static_cast<char>(msgid & 0xFF));
    packet.append(static_cast<char>((msgid >> 8) & 0xFF));
    packet.append(static_cast<char>((msgid >> 16) & 0xFF));
    packet.append(payload);

    const quint16 crc = MavlinkMessageParser::calculateCrc16(packet.mid(1), MavlinkMessageParser::getCrcExtra(msgid));
    packet.append(static_cast<char>(crc & 0xFF));
    packet.append(static_cast<char>((crc >> 8) & 0xFF));
    return packet;
}

QByteArray MavlinkMessageParser::buildHeartbeatPacket(quint8 seq, quint8 sysid, quint8 compid, quint16 flightMode)
{
    QByteArray payload;
    QDataStream stream(&payload, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream << static_cast<quint32>(flightMode)
           << static_cast<quint8>(2)  // MAV_TYPE_QUADROTOR
           << static_cast<quint8>(12) // MAV_AUTOPILOT_PX4
           << static_cast<quint8>(128)
           << static_cast<quint8>(4)  // MAV_STATE_ACTIVE
           << static_cast<quint8>(3); // mavlink_version
    return wrapMavlink2Packet(seq, sysid, compid, MAVLINK_MSG_ID_HEARTBEAT, payload);
}

QByteArray MavlinkMessageParser::buildGlobalPositionPacket(quint8 seq, quint8 sysid, quint8 compid,
                                                           double latitude, double longitude, double altitude,
                                                           quint16 flightMode)
{
    QByteArray payload;
    QDataStream stream(&payload, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::LittleEndian);
    const quint32 timeBootMs = static_cast<quint32>(QDateTime::currentMSecsSinceEpoch() % 4294967295ULL);
    const qint32 latE7 = static_cast<qint32>(latitude * 1e7);
    const qint32 lonE7 = static_cast<qint32>(longitude * 1e7);
    const qint32 altMm = static_cast<qint32>(altitude * 1000.0);

    stream << timeBootMs << latE7 << lonE7 << altMm << flightMode;
    return wrapMavlink2Packet(seq, sysid, compid, MAVLINK_MSG_ID_GLOBAL_POSITION_INT, payload);
}

QByteArray MavlinkMessageParser::buildCommandLongPacket(quint8 seq, quint8 sysid, quint8 compid,
                                                        quint8 targetSysid, quint8 targetCompid,
                                                        quint16 command, float param7)
{
    QByteArray payload;
    QDataStream stream(&payload, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream.setFloatingPointPrecision(QDataStream::SinglePrecision);
    stream << param7 << command << targetSysid << targetCompid << static_cast<quint8>(0);
    return wrapMavlink2Packet(seq, sysid, compid, MAVLINK_MSG_ID_COMMAND_LONG, payload);
}

QByteArray MavlinkMessageParser::buildCommandAckPacket(quint8 seq, quint8 sysid, quint8 compid,
                                                       quint16 command, quint8 result)
{
    QByteArray payload;
    QDataStream stream(&payload, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream << command << result;
    return wrapMavlink2Packet(seq, sysid, compid, MAVLINK_MSG_ID_COMMAND_ACK, payload);
}
