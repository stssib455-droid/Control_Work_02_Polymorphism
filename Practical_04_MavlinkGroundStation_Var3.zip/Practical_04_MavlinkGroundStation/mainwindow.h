#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDateTime>
#include <QtCharts/QChart>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class TelemetryModel;
class MavlinkManager;
class UavSimulator;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Управление UDP-каналом НСУ
    void on_btnStartLink_clicked();
    void on_btnStopLink_clicked();

    // Команды управления БПЛА (Вариант 3)
    void on_btnTakeoff_clicked();
    void on_btnLand_clicked();
    void on_btnStop_clicked();

    // Управление встроенным эмулятором БПЛА
    void on_btnStartUav_clicked();
    void on_btnDisconnectUav_clicked();
    void on_btnCorruptPacket_clicked();
    void on_btnDropPackets_clicked();

    // Слоты обновления GUI от модели и сетевого слоя
    void onTelemetryChanged(double latitude,
                            double longitude,
                            double altitude,
                            const QString &flightMode,
                            quint8 systemId,
                            quint8 componentId);

    void onLinkStateChanged(bool connected,
                            const QString &address,
                            quint16 port);

    void onPacketReceived(quint64 received,
                          quint64 lost,
                          quint64 corrupted);

    void onCommandResult(int command,
                         bool accepted,
                         const QString &message);

    void onMavlinkError(const QString &message);
    void appendNetworkEvent(const QString &eventMessage);

private:
    void setupChart();
    void setupTelemetryTable();
    void setCommandButtonsEnabled(bool enabled);

    Ui::MainWindow *ui;
    TelemetryModel *m_telemetryModel = nullptr;
    MavlinkManager *m_mavlinkManager = nullptr;
    UavSimulator *m_uavSimulator = nullptr;

    QChart *m_chart = nullptr;
    QLineSeries *m_altitudeSeries = nullptr;
    QValueAxis *m_axisX = nullptr;
    QValueAxis *m_axisY = nullptr;

    double m_timeSeconds = 0.0;
    QDateTime m_lastTableInsertTime;
    bool m_wasEverConnected = false;
};

#endif // MAINWINDOW_H
