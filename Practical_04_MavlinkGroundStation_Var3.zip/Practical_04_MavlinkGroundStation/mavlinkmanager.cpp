#include "mavlinkmanager.h"
#include "telemetrymodel.h"
#include "mavlinkmessageparser.h"
#include <QNetworkDatagram>

MavlinkManager::MavlinkManager(TelemetryModel *telemetry, QObject *parent)
    : QObject(parent), m_telemetry(telemetry)
{
    m_linkTimer = new QTimer(this);
    m_linkTimer->setInterval(1000);
    connect(m_linkTimer, &QTimer::timeout,
            this, &MavlinkManager::checkLinkTimeout);

    m_ackTimer = new QTimer(this);
    m_ackTimer->setSingleShot(true);
    m_ackTimer->setInterval(3000);
    connect(m_ackTimer, &QTimer::timeout,
            this, &MavlinkManager::onAckTimeout);
}

bool MavlinkManager::start(quint16 listenPort)
{
    if (m_udpSocket) {
        m_udpSocket->close();
        m_udpSocket->deleteLater();
        m_udpSocket = nullptr;
    }

    m_udpSocket = new QUdpSocket(this);
    if (!m_udpSocket->bind(QHostAddress::AnyIPv4, listenPort)) {
        emit errorOccurred(QString("Не удалось открыть UDP-порт %1: %2")
                               .arg(listenPort)
                               .arg(m_udpSocket->errorString()));
        return false;
    }

    connect(m_udpSocket, &QUdpSocket::readyRead,
            this, &MavlinkManager::onReadyRead);

    m_receivedPackets = 0;
    m_lostPackets = 0;
    m_corruptedPackets = 0;
    m_lastSequence = -1;
    m_heartbeatLogged = false;
    m_lastFlightMode.clear();
    m_linkConnected = false;
    m_lastPacketTime = QDateTime();

    m_linkTimer->start();
    emit linkStateChanged(false, QString(), 0);
    emit packetReceived(m_receivedPackets, m_lostPackets, m_corruptedPackets);
    emit networkEventLogged(QString("UDP-порт %1 открыт. Ожидание телеметрии БПЛА...").arg(listenPort));
    return true;
}

void MavlinkManager::stop()
{
    m_linkTimer->stop();
    m_ackTimer->stop();

    if (m_udpSocket) {
        m_udpSocket->close();
        m_udpSocket->deleteLater();
        m_udpSocket = nullptr;
    }

    if (m_linkConnected) {
        m_linkConnected = false;
        emit linkStateChanged(false, m_lastAddress, m_lastPort);
    }
    emit networkEventLogged("UDP-канал закрыт оператором");
}

void MavlinkManager::setTarget(const QString &address, quint16 port)
{
    m_targetAddress = QHostAddress(address);
    m_targetPort = port;
}

quint64 MavlinkManager::receivedPackets() const { return m_receivedPackets; }
quint64 MavlinkManager::lostPackets() const { return m_lostPackets; }
quint64 MavlinkManager::corruptedPackets() const { return m_corruptedPackets; }

void MavlinkManager::onReadyRead()
{
    while (m_udpSocket && m_udpSocket->hasPendingDatagrams()) {
        QNetworkDatagram datagram = m_udpSocket->receiveDatagram();
        if (!datagram.isValid()) {
            continue;
        }

        // Преобразуем IPv4-mapped IPv6 адрес вида ::ffff:127.0.0.1 в чистый IPv4
        QHostAddress senderAddr = datagram.senderAddress();
        bool ok = false;
        quint32 ipv4 = senderAddr.toIPv4Address(&ok);
        if (ok) {
            senderAddr = QHostAddress(ipv4);
        }

        m_lastAddress = senderAddr.toString();
        m_lastPort = datagram.senderPort();
        m_lastPacketTime = QDateTime::currentDateTime();

        // Если адрес БПЛА не был задан вручную, запоминаем адрес отправителя
        if (m_targetAddress.isNull() || m_targetPort == 0) {
            m_targetAddress = senderAddr;
            m_targetPort = m_lastPort;
        }

        processDatagram(datagram.data());
    }
}

void MavlinkManager::processDatagram(const QByteArray &data)
{
    ParsedMavlinkPacket packet = MavlinkMessageParser::parsePacket(data);
    if (!packet.valid) {
        m_corruptedPackets++;
        emit packetReceived(m_receivedPackets, m_lostPackets, m_corruptedPackets);
        emit errorOccurred(packet.errorReason);
        emit networkEventLogged(QString("Ошибка пакета: %1").arg(packet.errorReason));
        return;
    }

    m_receivedPackets++;

    // Первое подключение или восстановление связи (Вариант 3)
    if (!m_linkConnected) {
        m_linkConnected = true;
        emit linkStateChanged(true, m_lastAddress, m_lastPort);
        emit networkEventLogged(QString("Принят пакет от %1:%2 (Связь установлена)")
                                    .arg(m_lastAddress)
                                    .arg(m_lastPort));
    }

    // Проверка последовательности seq (0..255)
    if (m_lastSequence >= 0) {
        const qint64 expected = (m_lastSequence + 1) % 256;
        if (packet.seq != expected) {
            const qint64 lost = (packet.seq - expected + 256) % 256;
            if (lost > 0 && lost < 100) {
                m_lostPackets += static_cast<quint64>(lost);
                emit networkEventLogged(QString("Потеря пакетов: %1 (ожидался seq=%2, получен seq=%3)")
                                            .arg(lost)
                                            .arg(expected)
                                            .arg(packet.seq));
            }
        }
    }
    m_lastSequence = packet.seq;
    emit packetReceived(m_receivedPackets, m_lostPackets, m_corruptedPackets);

    m_targetSystemId = packet.sysid;
    m_targetComponentId = packet.compid;

    if (packet.msgid == MAVLINK_MSG_ID_HEARTBEAT) {
        if (!m_heartbeatLogged) {
            m_heartbeatLogged = true;
            emit networkEventLogged(QString("MAVLink HEARTBEAT, sysid=%1, compid=%2")
                                        .arg(packet.sysid)
                                        .arg(packet.compid));
        }
        if (!m_lastFlightMode.isEmpty() && m_lastFlightMode != packet.flightModeName) {
            emit networkEventLogged(QString("Смена режима полёта: %1 -> %2")
                                        .arg(m_lastFlightMode, packet.flightModeName));
        }
        m_lastFlightMode = packet.flightModeName;
    } else if (packet.msgid == MAVLINK_MSG_ID_GLOBAL_POSITION_INT) {
        if (!m_lastFlightMode.isEmpty() && m_lastFlightMode != packet.flightModeName) {
            emit networkEventLogged(QString("Смена режима полёта: %1 -> %2")
                                        .arg(m_lastFlightMode, packet.flightModeName));
        }
        m_lastFlightMode = packet.flightModeName;

        emit telemetryReceived(packet.latitude,
                               packet.longitude,
                               packet.altitude,
                               packet.flightModeName,
                               packet.sysid,
                               packet.compid);
    } else if (packet.msgid == MAVLINK_MSG_ID_COMMAND_ACK) {
        m_ackTimer->stop();
        m_pendingCommand = -1;

        QString resultText;
        switch (packet.ackResult) {
        case MAV_RESULT_ACCEPTED:
            resultText = "Команда принята (ACCEPTED)";
            break;
        case MAV_RESULT_TEMPORARILY_REJECTED:
            resultText = "Команда временно отклонена";
            break;
        case MAV_RESULT_DENIED:
            resultText = "Команда отклонена (DENIED)";
            break;
        case MAV_RESULT_UNSUPPORTED:
            resultText = "Команда не поддерживается";
            break;
        case MAV_RESULT_FAILED:
            resultText = "Ошибка выполнения команды";
            break;
        case MAV_RESULT_IN_PROGRESS:
            resultText = "Команда выполняется (IN_PROGRESS)";
            break;
        default:
            resultText = "Неизвестный результат";
            break;
        }

        const bool accepted = (packet.ackResult == MAV_RESULT_ACCEPTED ||
                               packet.ackResult == MAV_RESULT_IN_PROGRESS);
        emit commandResult(static_cast<int>(packet.ackCommand), accepted, resultText);
        emit networkEventLogged(QString("Получен COMMAND_ACK (CMD=%1): %2")
                                    .arg(packet.ackCommand)
                                    .arg(resultText));
    }
}

void MavlinkManager::checkLinkTimeout()
{
    if (!m_lastPacketTime.isValid()) {
        return;
    }

    const qint64 elapsedMs = m_lastPacketTime.msecsTo(QDateTime::currentDateTime());
    if (elapsedMs > 3000 && m_linkConnected) {
        m_linkConnected = false;
        m_heartbeatLogged = false;
        emit linkStateChanged(false, m_lastAddress, m_lastPort);
        emit errorOccurred("Связь с БПЛА потеряна");
        emit networkEventLogged(QString("Связь потеряна (последний пакет: %1)")
                                    .arg(m_lastPacketTime.toString("hh:mm:ss")));
    }
}

void MavlinkManager::onAckTimeout()
{
    if (m_pendingCommand >= 0) {
        const int cmd = m_pendingCommand;
        m_pendingCommand = -1;
        emit commandResult(cmd, false, "Подтверждение не получено (тайм-аут 3 с)");
        emit networkEventLogged(QString("Тайм-аут COMMAND_ACK для команды %1").arg(cmd));
    }
}

void MavlinkManager::sendCommandInternal(quint16 command, float param7, const QString &humanTitle)
{
    if (!m_udpSocket || m_targetAddress.isNull() || m_targetPort == 0) {
        emit errorOccurred("Адрес БПЛА не задан или канал закрыт");
        return;
    }

    if (!m_telemetry || !m_telemetry->isLinkConnected()) {
        emit errorOccurred("Невозможно отправить команду: нет связи");
        return;
    }

    const QByteArray datagram = MavlinkMessageParser::buildCommandLongPacket(
        m_txSequence++,
        m_systemId,
        m_componentId,
        m_targetSystemId,
        m_targetComponentId,
        command,
        param7);

    const qint64 sent = m_udpSocket->writeDatagram(datagram, m_targetAddress, m_targetPort);
    if (sent == -1) {
        emit errorOccurred("Ошибка отправки команды по UDP");
        return;
    }

    m_pendingCommand = command;
    m_ackTimer->start();

    emit commandSent(static_cast<int>(command), static_cast<double>(param7));
    emit networkEventLogged(QString("Отправлена команда %1 (CMD=%2)").arg(humanTitle).arg(command));
}

void MavlinkManager::sendTakeoff(double targetAltitude)
{
    sendCommandInternal(MAV_CMD_NAV_TAKEOFF,
                        static_cast<float>(targetAltitude),
                        QString("ВЗЛЁТ на %1 м").arg(targetAltitude, 0, 'f', 0));
}

void MavlinkManager::sendLand()
{
    sendCommandInternal(MAV_CMD_NAV_LAND, 0.0f, "ПОСАДКА");
}

void MavlinkManager::sendStop()
{
    sendCommandInternal(MAV_CMD_DO_FLIGHTTERMINATION, 1.0f, "СТОП / УДЕРЖАНИЕ");
}
